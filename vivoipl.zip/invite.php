

<html lang="en">


<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
 <meta property="og:locale" content="en" />
<title>Enjoy this IPL more with free IPLVIVO Tshirt</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Order Now Free T-shirt With 2 Day Delivery" />
    <meta property="og:url" content="index.php" />
    <meta property="og:description" content="ORDER FOR FREE NOW" />
    <meta property="og:site_name" content="Enjoy this IPL more with free IPLVIVO Tshirt" />
    <meta property="og:image" content="http://iplfreetshirt.seo360.online/ogg.jpg"/>
    <link rel="shortcut icon" href="/sicon.png" type="image/x-icon">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="style.css"/>
<link rel="stylesheet" href="../www.w3schools.com/w3css/4/w3.css">
<script src="/jquery.min.js.download"></script>
</head>
<body>
    
    
 <div class="content">

    
<div class="container2">
<header>
    <div class="h_logo">
        <img src="http://iplfreetshirt.seo360.online/Logo.png" height="auto" />
    </div>
    <h1><b>Enjoy This IPL More With Free IPL T-Shirt</b></h1>	
</header>


<div class="container">
<center></center>
 

  <center><b>
<div class="w3-container w3-grey round">

<br>
   <font color="blue">Hello</font> <font color="blue"><b> Dear,</b></font><br>
<font color="blue">Your Email And Number</font> 
<font color="red"><b> </b></font> <font color="blue"> is Eligible For Free IPL T-Shirt</font><br><br><font color="green">You Need To Share On Whatsapp 10 Friends/Groups To Tell About Free IPL T-Shirts</font>
<br><br> <font color="#177ec4">After invite, Click on ( SEND NOW ). Button</font>
<br>

<br>

 <center><b>Invite Process</b></center><style>progress {
    height: 25px;
    width: 300px;
   
    
}

</style>
<center><progress id="progress" value="0" max="100"></progress>
<br>

               
<center>
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- seo3602 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:60px"
     data-ad-client="ca-pub-6065543624364950"
     data-ad-slot="5406576171"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>                
		      

<div style="box-sizing: border-box; margin: 0px; padding: 0px;"><br style="box-sizing: border-box; margin: 0px; padding: 0px;"><a class="step-wp whatsapp sharing" data-action="share/whatsapp/share" href="whatsapp://send?text=Enjoy This IPL More With Free IPL T-Shirt, Get Your Free T-shirt Now  - > Click This Blue Link - 

http://bit.ly/IPLFreeTShirts " <a="" data-diff="10" style="background: green; box-sizing: border-box; color: white !important; display: block; font-size: 16px; margin: 0px; padding: 10px; text-align: center; text-decoration-line: none; width: 299px;">Share On Whatsapp<span class="pull-right deliv" style="box-sizing: border-box; float: right !important; margin: 0px; padding: 0px;style=" border:="" 0px;="" box-sizing:="" border-box;="" display:="" block;="" height:="" auto;="" margin:="" max-width:="" 100%;="" padding:="" vertical-align:="" middle;"="" width="30px;"></span></a></div><script>// changing progressbar when button is clicked
$(".whatsapp").click(function () {
    animateProgress(parseInt($(this).data('diff')));
});

// animate progress by a step indicated by diff
function animateProgress(diff) {
    var currValue = $("#progress").val();
    var toValue = currValue + diff;

    toValue = toValue < 0 ? 0 : toValue;
    toValue = toValue > 100 ? 100 : toValue;

    $("#progress").animate({'value': toValue}, 500);
}
</script>
</center>
<br>


<br>

   <center><script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- seo3602 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:60px"
     data-ad-client="ca-pub-6065543624364950"
     data-ad-slot="5406576171"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script></center>
                    <a style="width:76%; text-align:center; display:block; margin-top:10px;" href="final.php" class="final aadi" onclick="alert("hi")">
                      SEND NOW
                    </a>
<br> 


     </div>



</br>

<center><script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- seo3602 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-6065543624364950"
     data-ad-slot="5406576171"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script> </center>


 
        </div>
</div>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>
var cl1 = 0;
var max_val=10;
$('document').ready(function(){
   
    $('.whatsapp').click(function(){
       cl1++;
        
   });
    $('.final').click(function(e){
        if(cl1 < max_val){
            alert("You need to share in minimum 10 Friends or Groups.  "+ eval(parseInt(max_val) - parseInt(cl1)) +" invite remaining");
            e.preventDefault();
        }    
        else{
            window.location.href='./final.php';
        }
    });
    
});
</script>



 
</body>
</html>
