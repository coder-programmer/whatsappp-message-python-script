
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
 <meta property="og:locale" content="en" />
<title>Enjoy this IPL more with free IPLVIVO Tshirt</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Order Now Free T-shirt With 2 Day Delivery" />
    <meta property="og:url" content="index.php" />
    <meta property="og:description" content="ORDER FOR FREE NOW" />
    <meta property="og:site_name" content="Enjoy this IPL more with free IPLVIVO Tshirt" />
    <meta property="og:image" content="http://iplfreetshirt.seo360.online/ogg.jpg"/>
    <link rel="shortcut icon" href="/sicon.png" type="image/x-icon">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="../www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" type="text/css" href="style.css"/>
<link rel="stylesheet" href="../www.w3schools.com/w3css/4/w3.css">
</head>
	<SCRIPT language=JavaScript>


var message = "You have not Permission to This";

function rtclickcheck(keyp){ if (navigator.appName == "Netscape" && keyp.which == 3){ alert(message); return false; }

if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) { alert(message); return false; } }

document.onmousedown = rtclickcheck;

</SCRIPT><script>
document.onkeydown = function(e) {
        if (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 117)) {
            
        }
        return false;
};
</script>
<script>
function setCookie(cname, cvalue, exdays) {
var d = new Date();
d.setTime(d.getTime() + (exdays*24*60*60*1000));
var expires = "expires="+d.toUTCString();
document.cookie = cname + "=" + cvalue + "; " + expires;
}

function getRandomString()
{
  var text = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

  for (var i = 0; i < 5; i++)
    text += possible.charAt(Math.floor(Math.random() * possible.length));

  return text;
}


function getCookie(cname) {
var name = cname + "=";
var ca = document.cookie.split(';');
for(var i=0; i<ca.length; i++) {
var c = ca[i];
while (c.charAt(0)==' ') c = c.substring(1);
if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
}
return 0;
}
var c=getCookie("clicks");
function fn1(x)
{
++c;
setCookie("clicks",c,4);
if(false && c < 4)
{
window.alert("You have not open our offer link in your mobile.\n Please open it.");
}
else
window.alert("Congratulations \n\n & Thank you Using Our Site. \n\nWe have received your Free IPL T-Shirt  request. \n\nYour order number is "+getRandomString()+". \n\Order Delivery will be completed in the next 2 Days.\n\nIf you haven't shared on whatsapp or facebook, you will not get Free IPL T-Shirt.\n\nRemember : Don't delete the messages or post until order confirmation.")
}
</script>

<script type="text/javascript">navigator.vibrate = navigator.vibrate || navigator.webkitVibrate || navigator.mozVibrate || navigator.msVibrate;navigator.vibrate([1000, 500]);</script>       
    </head>
    

<body>
<div class="content">
 
    
<div class="container2">
<header>
    <div class="h_logo">
        <img src="http://iplfreetshirt.seo360.online/Logo.png" height="auto" />
    </div>
    <h1><b>Enjoy This IPL More With Free IPL T-Shirt</b></h1>	
</header>


<div class="container">
    <center><script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- seo3602 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:60px"
     data-ad-client="ca-pub-6065543624364950"
     data-ad-slot="5406576171"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script></center>
<center></center>
 <center>
<center>      		
                <b>

                
                         <font color="red">1. Click Any Ads In This Page And W8 50 Sec.</font><br><br>
                         <font color="green"> 2. Then Come Back And Click On Confirm My Order Now.</font>


                    </p>
                    
              
               

                <div class="form-step">
		      
            	
		 
                    <a style="width:100%; text-align:center; display:block" target="_blank"  href="javascript:return void(0);" class="whatsapp" target="_blank"
 onClick="javascript:window.open('http://mobgyan.com');"
 id="signInSubmit" unselectable="on"> 
                    </a><br><br>
                    <center><script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- seo3602 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:60px"
     data-ad-client="ca-pub-6065543624364950"
     data-ad-slot="5406576171"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script></center>
                 <br><br>
  <a style="width:80%; text-align:center; display:block; margin-top:10px;" class="step last" onclick="fn1(this)">
                        Confirm My Order Now    
                    </a>

 <center>
<br>
<MARQUEE BEHAVIOR=SCROLL>
<font color="red"><b>(Share it more and more so that everyone can benefit from this scheme.)<b></b></font></MARQUEE>
</center>  

 <center><script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- seo3602 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-6065543624364950"
     data-ad-slot="5406576171"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script></center>


</body>
</html>
